function somar(a,b){ return 0 }
module.exports=somar;