function media(a,b,c){ return '' }
module.exports=media;