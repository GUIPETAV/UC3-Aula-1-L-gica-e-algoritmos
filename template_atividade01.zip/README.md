# 🧩 Atividade 01 – Fundamentos de Programação Estruturada (JavaScript)

Complete os arquivos na pasta src conforme os exercícios propostos.
