const somar=require("../src/exercicio1");
test("somar 2 + 3 = 5",()=>{ expect(somar(2,3)).toBe(5); });
