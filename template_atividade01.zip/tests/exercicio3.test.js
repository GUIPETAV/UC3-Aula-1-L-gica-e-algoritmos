const media=require("../src/exercicio3");
test("média 7,7,7 → aprovado",()=>{ expect(media(7,7,7)).toBe("aprovado"); });
